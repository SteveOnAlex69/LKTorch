"""
My C++ Deep Learning Engine
"""
from __future__ import annotations
import collections.abc
import numpy
import numpy.typing
import typing
__all__: list[str] = ['Abs', 'Abs_Layer', 'Acos', 'AdaGrad', 'Adam', 'Asin', 'Atan', 'BCELoss', 'Cbrt', 'Cbrt_Layer', 'Conv2D', 'Cos', 'Cosh', 'Cosh_Layer', 'CreateTensor', 'CrossEntropyLoss', 'Cube', 'Cube_Layer', 'CustomRandom', 'DecayDescent', 'Dropout', 'Dropout_Layer', 'Exp', 'ExpNormalize', 'ExpNormalize_Layer', 'Exp_Layer', 'Flatten', 'Flatten_Layer', 'Functional_Layer', 'GradientDescent', 'GradientMomentum', 'HingeLoss', 'Huber', 'HuberLoss', 'Huber_Layer', 'Inverse', 'Inverse_Layer', 'KL_Divergence', 'LinearLayer', 'LinearNormalize', 'LinearNormalize_Layer', 'Log', 'Log_Layer', 'MAELoss', 'MSELoss', 'MapValue', 'Max', 'MaxIndex', 'MaxPool', 'MaxPool_Layer', 'Max_Layer', 'Mean', 'MeanAll', 'Mean_Layer', 'Merge', 'Min', 'MinIndex', 'MinPool', 'MinPool_Layer', 'Min_Layer', 'Module', 'NormalRandom', 'Ones', 'Permute', 'PermuteDimension', 'PermuteDimension_Layer', 'RMSELoss', 'RMSProp', 'ReadFile', 'Reshape', 'Reshape_Layer', 'ScalarAdd', 'ScalarAdd_Layer', 'ScalarDivide', 'ScalarDivide_Layer', 'ScalarMultiply', 'ScalarMultiply_Layer', 'ScalarSubtract', 'ScalarSubtract_Layer', 'Sequential', 'Sigmoid', 'Sigmoid_Layer', 'Sin', 'Sinh', 'Sinh_Layer', 'Slice', 'Slice_Layer', 'Sqr', 'Sqr_Layer', 'Sqrt', 'Sqrt_Layer', 'Sum', 'SumAll', 'Sum_Layer', 'Tan', 'Tanh', 'Tanh_Layer', 'Tensor', 'TensorFunction', 'Transpose', 'Transpose_Layer', 'Unfold', 'Unfold_Layer', 'UniformRandom', 'UniformValue', 'ValueMultiply', 'WriteFile', 'Zeros', 'activate_backprop', 'backprop_activated', 'deactivate_backprop', 'reLU', 'reLU_Layer', 'set_backprop_status', 'toggle_backprop']
class Abs_Layer(Module):
    def __init__(self) -> None:
        ...
class AdaGrad(GradientDescent):
    """
    Adaptive Gradient Algorithm.
    """
    def __init__(self, learning_rate: typing.SupportsFloat | typing.SupportsIndex = 0.0) -> None:
        ...
    @typing.overload
    def add_parameter(self, ts: Tensor) -> None:
        ...
    @typing.overload
    def add_parameter(self, ts: collections.abc.Sequence[Tensor]) -> None:
        ...
class Adam(AdaGrad):
    """
    Adaptive Moment Estimation.
    """
    def __init__(self, learning_rate: typing.SupportsFloat | typing.SupportsIndex = 0.0, glide: typing.SupportsFloat | typing.SupportsIndex = 0.9900000095367432, decay: typing.SupportsFloat | typing.SupportsIndex = 0.9900000095367432) -> None:
        ...
    @typing.overload
    def add_parameter(self, ts: Tensor) -> None:
        ...
    @typing.overload
    def add_parameter(self, ts: collections.abc.Sequence[Tensor]) -> None:
        ...
class Cbrt_Layer(Module):
    def __init__(self) -> None:
        ...
class Conv2D(Module):
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, in_features: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], out_features: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex] = [1]) -> None:
        """
        Convolutional Layers.
        """
class Cosh_Layer(Module):
    def __init__(self) -> None:
        ...
class Cube_Layer(Module):
    def __init__(self) -> None:
        ...
class DecayDescent(GradientMomentum):
    """
    Momentum with LR Decay.
    """
    def __init__(self, learning_rate: typing.SupportsFloat | typing.SupportsIndex = 0.0, glide: typing.SupportsFloat | typing.SupportsIndex = 0.0, decay: typing.SupportsFloat | typing.SupportsIndex = 0.0) -> None:
        ...
    def decay_learning_rate(self) -> None:
        ...
    def get_decay(self) -> float:
        ...
    def set_decay(self, dc: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
class Dropout_Layer(Module):
    def __init__(self, rate: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
class ExpNormalize_Layer(Module):
    def __init__(self) -> None:
        ...
class Exp_Layer(Module):
    def __init__(self) -> None:
        ...
class Flatten_Layer(Module):
    def __init__(self, dim: typing.SupportsInt | typing.SupportsIndex = 0) -> None:
        ...
class Functional_Layer(Module):
    def __init__(self, f: TensorFunction) -> None:
        """
        Wraps a custom differentiable TensorFunction global wrapper.
        """
class GradientDescent:
    """
    Standard Stochastic Gradient Descent.
    """
    def __init__(self, learning_rate: typing.SupportsFloat | typing.SupportsIndex = 0.0) -> None:
        ...
    @typing.overload
    def add_parameter(self, ts: Tensor) -> None:
        ...
    @typing.overload
    def add_parameter(self, ts: collections.abc.Sequence[Tensor]) -> None:
        ...
    def get_learning_rate(self) -> float:
        ...
    def set_learning_rate(self, lr: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
    def step(self) -> None:
        """
        Update all registered parameters using calculated gradients.
        """
    def zero_gradient(self) -> None:
        """
        Wipes the gradients from all tracked tensors.
        """
class GradientMomentum(GradientDescent):
    """
    SGD with Momentum tracking.
    """
    def __init__(self, learning_rate: typing.SupportsFloat | typing.SupportsIndex = 0.0, glide: typing.SupportsFloat | typing.SupportsIndex = 0.0) -> None:
        ...
    def get_glide(self) -> float:
        ...
    def multiply_gradient(self) -> None:
        ...
    def set_glide(self, gl: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
class Huber_Layer(Module):
    def __init__(self, epsilon: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
class Inverse_Layer(Module):
    def __init__(self) -> None:
        ...
class LinearLayer(Module):
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, in_features: typing.SupportsInt | typing.SupportsIndex, out_features: typing.SupportsInt | typing.SupportsIndex) -> None:
        """
        Fully Connected linear transformation layer.
        """
class LinearNormalize_Layer(Module):
    def __init__(self) -> None:
        ...
class Log_Layer(Module):
    def __init__(self) -> None:
        ...
class MaxPool_Layer(Module):
    def __init__(self) -> None:
        ...
class Max_Layer(Module):
    def __init__(self) -> None:
        ...
class Mean_Layer(Module):
    def __init__(self) -> None:
        ...
class MinPool_Layer(Module):
    def __init__(self) -> None:
        ...
class Min_Layer(Module):
    def __init__(self) -> None:
        ...
class Module:
    """
    Abstract base class for all neural network modules.
    """
    def __call__(self, x: Tensor) -> Tensor:
        """
        Allows calling the module like a function instance.
        """
    def forward(self, x: Tensor) -> Tensor:
        """
        Virtual forward pass logic execution node.
        """
    def get_parameters(self) -> list[Tensor]:
        """
        Returns a list of trainable parameter Tensors.
        """
    def get_state_dict(self) -> list[list[float]]:
        """
        Extracts raw float data arrays representing module weights.
        """
    def load_state_dict(self, state_dict: collections.abc.Sequence[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex]]) -> None:
        """
        Restores weights from raw float data matrix layouts.
        """
class PermuteDimension_Layer(Module):
    def __init__(self, dim: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> None:
        ...
class RMSProp(AdaGrad):
    """
    Root Mean Square Propagation.
    """
    def __init__(self, learning_rate: typing.SupportsFloat | typing.SupportsIndex = 0.0, decay_rate: typing.SupportsFloat | typing.SupportsIndex = 0.8999999761581421) -> None:
        ...
class Reshape_Layer(Module):
    def __init__(self, new_shape: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> None:
        ...
class ScalarAdd_Layer(Module):
    def __init__(self, scalar: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
class ScalarDivide_Layer(Module):
    def __init__(self, scalar: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
class ScalarMultiply_Layer(Module):
    def __init__(self, scalar: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
class ScalarSubtract_Layer(Module):
    def __init__(self, scalar: typing.SupportsFloat | typing.SupportsIndex) -> None:
        ...
class Sequential(Module):
    """
    Chains modules into linear structural pipelines.
    """
    def __getitem__(self, index: typing.SupportsInt | typing.SupportsIndex) -> Module:
        """
        Retrieves reference pointers via block placement locations.
        """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, modules: collections.abc.Sequence[Module]) -> None:
        """
        Construct sequential chains from array lists.
        """
    def push_back(self, module: Module) -> None:
        """
        Appends a module block wrapper link.
        """
class Sigmoid_Layer(Module):
    def __init__(self) -> None:
        ...
class Sinh_Layer(Module):
    def __init__(self) -> None:
        ...
class Slice_Layer(Module):
    def __init__(self, start_indices: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], end_indices: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> None:
        ...
class Sqr_Layer(Module):
    def __init__(self) -> None:
        ...
class Sqrt_Layer(Module):
    def __init__(self) -> None:
        ...
class Sum_Layer(Module):
    def __init__(self) -> None:
        ...
class Tanh_Layer(Module):
    def __init__(self) -> None:
        ...
class Tensor:
    def MapValue(self, mapping: collections.abc.Sequence[tuple[typing.SupportsInt | typing.SupportsIndex, typing.SupportsInt | typing.SupportsIndex]], stride: tuple[typing.SupportsInt | typing.SupportsIndex, typing.SupportsInt | typing.SupportsIndex], new_dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
        """
        Map the value in the tensor however you like
        """
    def Merge(self, other: Tensor) -> Tensor:
        """
        Merges/concatenates two tensors together along their matching dimensional parameters.
        """
    def Permute(self, target_dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], target_permutation: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
        """
        Permuting the element in the tensor however you like
        """
    def PermuteDimension(self, target_dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
        """
        Swapping the dimensions around.
        """
    def Reshape(self, new_shape: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
        """
        Reshapes the tensor to a new dimension mapping without altering underlying memory size.
        """
    def Slice(self, start_indices: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], end_indices: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
        """
        Slices a sub-region out of the tensor using coordinate boundaries.
        """
    def Transpose(self) -> Tensor:
        """
        Swap the top most 2 dimensions of the tensor.
        """
    def ValueMultiply(self, other: Tensor) -> Tensor:
        """
        Performs element-wise multiplication matching the structural bounds.
        """
    @typing.overload
    def __add__(self, arg0: Tensor) -> Tensor:
        ...
    @typing.overload
    def __add__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
        ...
    @typing.overload
    def __iadd__(self, arg0: Tensor) -> Tensor:
        ...
    @typing.overload
    def __iadd__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
        ...
    @typing.overload
    def __imul__(self, arg0: Tensor) -> Tensor:
        ...
    @typing.overload
    def __imul__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
        ...
    @typing.overload
    def __init__(self, dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], data: collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex]) -> None:
        """
        Initialize a Tensor with a given shape and populate it with a flat list of float values.
        """
    @typing.overload
    def __init__(self, data: typing.Annotated[numpy.typing.ArrayLike, numpy.float32]) -> None:
        """
        Initialize a Tensor from any nested Python list or NumPy array.
        """
    @typing.overload
    def __isub__(self, arg0: Tensor) -> Tensor:
        ...
    @typing.overload
    def __isub__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
        ...
    def __itruediv__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
        ...
    @typing.overload
    def __mul__(self, arg0: Tensor) -> Tensor:
        ...
    @typing.overload
    def __mul__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @typing.overload
    def __sub__(self, arg0: Tensor) -> Tensor:
        ...
    @typing.overload
    def __sub__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
        ...
    def __truediv__(self, arg0: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
        ...
    def accessA(self, indices: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> float:
        """
        Access the forward-pass value at a specific coordinate vector (e.g., [0, 2, 5]).
        """
    def accessGA(self, indices: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> float:
        """
        Access the gradient value (grad) at a specific coordinate vector.
        """
    def backward(self, is_root: bool = True) -> None:
        """
        Triggers the reverse-mode automatic differentiation (backpropagation) DAG from this node.
        """
    def clear(self) -> None:
        """
        Clears out underlying data or gradients safely.
        """
    def dimension(self) -> list[int]:
        """
        Returns a list containing the shape/dimensions of the tensor.
        """
    def empty(self) -> bool:
        """
        Returns True if the underlying tensor storage is empty or uninitialized.
        """
    def numpy(self) -> numpy.typing.NDArray[numpy.float32]:
        """
        Convert the Tensor back into a standard NumPy array.
        """
    def size(self) -> int:
        """
        Returns the total number of elements flattened inside the tensor.
        """
class TensorFunction:
    """
    Base class for differentiable activations.
    """
    def __call__(self, x: Tensor) -> Tensor:
        """
        Allows the instance to be called directly like a function: activation(tensor)
        """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, f: collections.abc.Callable[[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], typing.SupportsInt | typing.SupportsIndex], list[float]], dF: collections.abc.Callable[[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex], typing.SupportsInt | typing.SupportsIndex], list[float]]) -> None:
        """
        Initialize a TensorFunction by passing the forward and derivative vector functions.
        """
    def forward(self, x: Tensor) -> Tensor:
        """
        Run the forward pass of this mathematical function on a Tensor.
        """
class Transpose_Layer(Module):
    def __init__(self) -> None:
        ...
class Unfold_Layer(Module):
    def __init__(self, stride_d: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], stride: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex] = [], offset: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex] = []) -> None:
        ...
class reLU_Layer(Module):
    def __init__(self) -> None:
        ...
def BCELoss(prediction: Tensor, target: Tensor) -> Tensor:
    """
    Binary Cross Entropy Loss.
    """
def CreateTensor(data: typing.Annotated[numpy.typing.ArrayLike, numpy.float32]) -> Tensor:
    """
    Initialize a tensor by giving it a multidimensional array of float.
    """
def CrossEntropyLoss(prediction: Tensor, target: Tensor) -> Tensor:
    """
    Cross Entropy Loss for multi-class classification.
    """
def CustomRandom(dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], init_function: collections.abc.Callable[[typing.SupportsInt | typing.SupportsIndex], float]) -> Tensor:
    """
    Initialize a tensor using a custom Python lambda function.
    """
def Dropout(x: Tensor, rate: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
    """
    Drop out rate of the tensor
    """
def ExpNormalize(x: Tensor) -> Tensor:
    """
    Exponential normalize the outermost layer of the tensor
    """
def Flatten(x: Tensor, dim: typing.SupportsInt | typing.SupportsIndex = 0) -> Tensor:
    """
    Flatten the entire tensor
    """
def HingeLoss(prediction: Tensor, target: Tensor) -> Tensor:
    """
    Hinge Loss for SVMs.
    """
def Huber(x: Tensor, epsilon: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
    """
    Get the huber loss of the entire tensor
    """
def HuberLoss(prediction: Tensor, target: Tensor, epsilon: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
    """
    Huber Loss with epsilon smoothing.
    """
def KL_Divergence(prediction: Tensor, target: Tensor) -> Tensor:
    """
    Kullback-Leibler Divergence.
    """
def LinearNormalize(x: Tensor) -> Tensor:
    """
    Linear normalize the outermost layer of the tensor
    """
def MAELoss(prediction: Tensor, target: Tensor) -> Tensor:
    """
    Mean Absolute Error.
    """
def MSELoss(prediction: Tensor, target: Tensor) -> Tensor:
    """
    Mean Squared Error.
    """
def MapValue(tensor: Tensor, mapping: collections.abc.Sequence[tuple[typing.SupportsInt | typing.SupportsIndex, typing.SupportsInt | typing.SupportsIndex]], stride: tuple[typing.SupportsInt | typing.SupportsIndex, typing.SupportsInt | typing.SupportsIndex], new_dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
    """
    Map the value in the tensor however you like
    """
def MaxIndex(x: Tensor) -> Tensor:
    """
    Get the max index of the outermost layer of the tensor (backprop)
    """
def MaxPool(x: Tensor) -> Tensor:
    """
    Get the max of the outermost layer of the tensor
    """
def Mean(x: Tensor) -> Tensor:
    """
    Get the mean of the outermost layer of the tensor
    """
def MeanAll(x: Tensor) -> Tensor:
    """
    Get the mean of the entire tensor
    """
def Merge(tensor1: Tensor, tensor2: Tensor) -> Tensor:
    """
    Merges/concatenates two tensors together along their matching dimensional parameters.
    """
def MinIndex(x: Tensor) -> Tensor:
    """
    Get the min index of the outermost layer of the tensor (backprop)
    """
def MinPool(x: Tensor) -> Tensor:
    """
    Get the min of the outermost layer of the tensor
    """
def NormalRandom(dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], mean: typing.SupportsFloat | typing.SupportsIndex, deviation: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
    """
    Create a tensor filled with random numbers from a Gaussian/Normal distribution.
    """
def Ones(dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
    """
    Create a tensor filled with 1.0
    """
def Permute(tensor: Tensor, target_dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], target_permutation: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
    """
    Permuting the element in the tensor however you like
    """
def PermuteDimension(tensor: Tensor, target_dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
    """
    Swapping the dimensions around.
    """
def RMSELoss(prediction: Tensor, target: Tensor) -> Tensor:
    """
    Root Mean Squared Error.
    """
def ReadFile(path: str) -> list[list[float]]:
    """
    Read from a file.
    """
def Reshape(tensor: Tensor, new_shape: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
    """
    Reshapes the tensor to a new dimension mapping without altering underlying memory size.
    """
def ScalarAdd(tensor: Tensor, y: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
    """
    Scalar Add
    """
def ScalarDivide(tensor: Tensor, y: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
    """
    Scalar Divison
    """
def ScalarMultiply(tensor: Tensor, y: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
    """
    Scalar Multiply
    """
def ScalarSubtract(tensor: Tensor, y: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
    """
    Scalar Subtraction
    """
def Slice(tensor: Tensor, start_indices: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], end_indices: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
    """
    Slices a sub-region out of the tensor using coordinate boundaries.
    """
def Sum(x: Tensor) -> Tensor:
    """
    Get the sum of the outermost layer of the tensor
    """
def SumAll(x: Tensor) -> Tensor:
    """
    Get the sum of the entire tensor
    """
def Transpose(tensor: Tensor) -> Tensor:
    """
    Swap the top most 2 dimensions of the tensor.
    """
def Unfold(x: Tensor, stride_d: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], stride: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex] = [], offset: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex] = []) -> Tensor:
    """
    Unfold the tensor
    """
def UniformRandom(dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], l: typing.SupportsFloat | typing.SupportsIndex, r: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
    """
    Create a tensor filled with random numbers from a uniform distribution [l, r].
    """
def UniformValue(dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex], x: typing.SupportsFloat | typing.SupportsIndex) -> Tensor:
    """
    Create a tensor filled with a specific scalar value.
    """
def ValueMultiply(tensor1: Tensor, tensor2: Tensor) -> Tensor:
    """
    Performs element-wise multiplication matching the structural bounds.
    """
def WriteFile(content: collections.abc.Sequence[collections.abc.Sequence[typing.SupportsFloat | typing.SupportsIndex]], path: str) -> None:
    """
    Write to a file.
    """
def Zeros(dimension: collections.abc.Sequence[typing.SupportsInt | typing.SupportsIndex]) -> Tensor:
    """
    Create a tensor filled with 0.0
    """
def activate_backprop() -> None:
    """
    The functionality of this function is extremely complex, thus I'd rather not discuss it
    """
def backprop_activated() -> bool:
    """
    The functionality of this function is extremely complex, thus I'd rather not discuss it
    """
def deactivate_backprop() -> None:
    """
    The functionality of this function is extremely complex, thus I'd rather not discuss it
    """
def set_backprop_status(flag: bool) -> None:
    """
    The functionality of this function is extremely complex, thus I'd rather not discuss it
    """
def toggle_backprop() -> None:
    """
    The functionality of this function is extremely complex, thus I'd rather not discuss it
    """
Abs: TensorFunction  # value = <lktorch.TensorFunction object>
Acos: TensorFunction  # value = <lktorch.TensorFunction object>
Asin: TensorFunction  # value = <lktorch.TensorFunction object>
Atan: TensorFunction  # value = <lktorch.TensorFunction object>
Cbrt: TensorFunction  # value = <lktorch.TensorFunction object>
Cos: TensorFunction  # value = <lktorch.TensorFunction object>
Cosh: TensorFunction  # value = <lktorch.TensorFunction object>
Cube: TensorFunction  # value = <lktorch.TensorFunction object>
Exp: TensorFunction  # value = <lktorch.TensorFunction object>
Inverse: TensorFunction  # value = <lktorch.TensorFunction object>
Log: TensorFunction  # value = <lktorch.TensorFunction object>
Max: TensorFunction  # value = <lktorch.TensorFunction object>
Min: TensorFunction  # value = <lktorch.TensorFunction object>
Sigmoid: TensorFunction  # value = <lktorch.TensorFunction object>
Sin: TensorFunction  # value = <lktorch.TensorFunction object>
Sinh: TensorFunction  # value = <lktorch.TensorFunction object>
Sqr: TensorFunction  # value = <lktorch.TensorFunction object>
Sqrt: TensorFunction  # value = <lktorch.TensorFunction object>
Tan: TensorFunction  # value = <lktorch.TensorFunction object>
Tanh: TensorFunction  # value = <lktorch.TensorFunction object>
reLU: TensorFunction  # value = <lktorch.TensorFunction object>
